#!/usr/bin/with-contenv bashio
exec python3 /app/server.py

